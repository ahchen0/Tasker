import osmapi
api = osmapi.OsmApi()
api.Map(-180, -90, 180, 90)
import pdb
pdb.set_trace()

# Class that contains information for a spacecraft

class spacecraft:

	def __init__(self, name, line1, line2):
		self.name = name.strip()

		# Line 1
		self.catalogNumber = line1[2:8]
		self.intlDesignator = line1[9:16]
		self.epochYear = line1[18:19]
		self.epochDay = line1[20:31]
		self.firstDerivativeOfMeanMotion = line1[33:42]
		self.secondDerivativeOfMeanMotion = line1[44:51]
		self.dragTerm = line1[53:60]
		self.ephemerisType = line1[62]
		self.elementSetNumber = line1[64:67]
		self.elementSetNumberCheckSum = line1[68]

		# Line 2
		self.inclination = line2[8:15]
		self.rightAscensionOfAscendingNode = line2[17:24]
		self.eccentricity = line2[26:32]
		self.argumentOfPerigee = line2[34:41]
		self.meanAnomaly = line2[43:50]
		self.meanMotion = line2[52:62]
		self.revolutionNumberAtEpoch = line2[63:67]
		self.revolutionNumberAtEpochCheckSum = line2[68]

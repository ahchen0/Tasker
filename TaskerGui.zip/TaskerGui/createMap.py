import folium

# map = folium.Map(location=[42.2917472, -83.710949])
map = folium.Map()
map.save("osm.html")

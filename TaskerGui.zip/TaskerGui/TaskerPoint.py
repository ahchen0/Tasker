class Point:
    
    def __init__(self, name, lat, lon):
        self.name = name
        self.lat = lat
        self.lon = lon